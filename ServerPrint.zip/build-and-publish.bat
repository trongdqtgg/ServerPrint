@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title LAN Print - Build and Publish GitHub Release
echo ======================================================
echo   LAN Print - Build va Publish GitHub Release
echo ======================================================
echo.

where node >nul 2>nul || goto :NO_NODE
where npm >nul 2>nul || goto :NO_NODE

if not exist "package.json" (
  echo LOI: Khong tim thay package.json.
  echo Hay dat file build-and-publish.bat trong thu muc goc du an.
  goto :FAIL
)

for /f "delims=" %%v in ('node -p "require('./package.json').version"') do set "APP_VERSION=%%v"
for /f "delims=" %%o in ('node -p "require('./package.json').build.publish[0].owner"') do set "GH_OWNER=%%o"
for /f "delims=" %%r in ('node -p "require('./package.json').build.publish[0].repo"') do set "GH_REPO=%%r"

if not defined APP_VERSION goto :BAD_CONFIG
if not defined GH_OWNER goto :BAD_CONFIG
if not defined GH_REPO goto :BAD_CONFIG

echo Repository : https://github.com/%GH_OWNER%/%GH_REPO%
echo Version    : v%APP_VERSION%
echo.

if not defined GH_TOKEN (
  echo Chua co GH_TOKEN. Hay nhap token GitHub.
  echo Ky tu token se duoc an khi nhap.
  for /f "usebackq delims=" %%T in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=Read-Host 'GH_TOKEN' -AsSecureString; $p=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try {[Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)}"`) do set "GH_TOKEN=%%T"
  if not defined GH_TOKEN goto :FAIL
)

echo Kiem tra cau hinh...
node -e "const p=require('./package.json');const q=p.build&&p.build.publish&&p.build.publish[0];if(!q||q.provider!=='github'||!q.owner||!q.repo)throw Error('Thieu build.publish GitHub');if(!p.scripts||!p.scripts['dist:win:publish'])throw Error('Thieu dist:win:publish');console.log('Cau hinh hop le.')"
if errorlevel 1 goto :FAIL

choice /C YN /N /M "Build va publish v%APP_VERSION%? [Y/N]: "
if errorlevel 2 goto :CANCEL

echo.
echo [1/3] Cai dat dependencies...
if exist "package-lock.json" (call npm ci) else (call npm install)
if errorlevel 1 goto :FAIL

echo.
echo [2/3] Kiem tra cu phap...
call node --check main.js
if errorlevel 1 goto :FAIL

echo.
echo [3/3] Build NSIS va publish GitHub Release...
call npm run dist:win:publish
if errorlevel 1 goto :FAIL

echo.
echo ======================================================
echo THANH CONG: Da publish v%APP_VERSION%
echo https://github.com/%GH_OWNER%/%GH_REPO%/releases/tag/v%APP_VERSION%
echo Release can co: LAN-Print-%APP_VERSION%-x64.exe, latest.yml, .blockmap
echo ======================================================
pause
exit /b 0

:BAD_CONFIG
echo LOI: package.json chua co version hoac build.publish.
goto :FAIL

:NO_NODE
echo LOI: Chua cai Node.js LTS hoac Node.js chua co trong PATH.
goto :FAIL

:CANCEL
echo Da huy.
exit /b 0

:FAIL
echo.
echo BUILD/PUBLISH THAT BAI. Xem loi o phia tren.
pause
exit /b 1
